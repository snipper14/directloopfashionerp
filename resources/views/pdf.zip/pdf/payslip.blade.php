<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title></title>
    <style>
        .table-bordered table {
            border-collapse: collapse;
        }

        .table-bordered th,
        .table-bordered td,
        .table-bordered tr {
            /* border-bottom: 1px solid rgb(14, 13, 13);
            border-right: 1px solid rgb(14, 13, 13); */

        }

        .table-bordered td {
            padding: 4px !important;
        }

        .table-bordered thead {
            border-top: 1px solid rgb(14, 13, 13);
        }

        table {
            width: 100% !important;
        }

        .table-address {
            width: 100% !important;
            margin-bottom: 0rem;
            margin-top: -14px;
        }

        .right-cont {}

        .left-cont p {
            line-height: 0.6em;
            font-weight: 600;
        }

        .right-cont span {
            float: right;
            margin-right: 1rem;

        }

        .right-cont span p {
            line-height: 0.6em;
            font-weight: 600;
        }

        .table-address p {
            font-size: 0.8em;
        }

        .invoice {
            text-align: center;
            color: rgb(83, 81, 81);
            font-weight: 700;
            font-size: 1.4rem;
        }

        .company-name {
            color: #9A631D !important;
            font-family: 'Times New Roman', Times, serif !important;
            font-weight: 900 !important;
            font-size: 2.0rem !important;
        }

        .company-add {
            color: rgb(211, 79, 79);
            font-style: italic;
            font-weight: 600;
            font-size: 1rem;
        }

        .top-title {
            margin-left: -34px !important;

        }





        .line-wrapper {
            display: inline-block;
            width: 100%;
            justify-content: space-between;
            font-size: 0.8rem !important;
        }

        .card-header {
            display: flex !important;
            flex-direction: row !important;
            justify-content: space-between;
        }




        .top_row {
            display: table;
            width: 100%;
        }

        .top_row>div {
            display: table-cell;

            border-bottom: 1px solid #eee;
        }

        .top_row>.item-val {
            text-align: right !important;
        }

        .attribute {
            float: right;
        }

    </style>
</head>

<body>
    <table>

        <tr>
            <td class="top-title">
                <center> <img src="{{ Auth::user()->branch->img_path }}" height="70" width="100" /></center>

            </td>
            <td>
                <div><b class="company-name">
                        {{ Auth::user()->branch->business_name }}
                    </b>
                </div>

            </td>
        </tr>

    </table>

    <table>
        <tr>

            <td>
                <p> <b>Payslip Date: </b>{{ date('Y/m/d h:i:', time()) }}</p>
            </td>
        </tr>
    </table>

    <table>
        <tr>
            <td class="invoice">
                <p>PAYSLIP</p>
            </td>
        </tr>
        <tr>
           

                <td>
                    <b> Payslip for the month of
                        {{ $data['payroll_to'] }}
                    </b>
                </td>
         
        </tr>
    </table>
    <table style="width: 100%">
        <tr>
            <td>
                <div>Name</div>
            </td>
            <td>
                <div class="attribute">
                    {{ $data['employee']['first_name'] . ' ' . $data['employee']['last_name'] }}
                </div>
            </td>
        </tr>
        <tr>
            <td>
                <div>Job Number</div>
            </td>
            <td>
                <div class="attribute">{{ $data['employee']['job_no'] }}</div>
            </td>
        </tr>

        <tr>
            <td>
                <div>Job title</div>
            </td>
            <td>
                <div class="attribute">
                    {{ $data['employee']['employee_type']['name'] }}</div>
            </td>
        </tr>
        <tr>
            <td>
                <div>Dept./Region:</div>
            </td>
            <td>
                <div class="attribute">
                    {{ $data['employee']['department']['department'] }}</div>
            </td>
        </tr>
    </table>
    <hr />


    <table style="width: 100%">
        <tr>
            <td>
                <div>Basic Pay:</div>
            </td>
            <td>
                <div class="attribute">
                    {{ number_format($data['employee']['salary'], 2) }}
                </div>
            </td>
        </tr>

      

        <tr>
            <td>
                <div>Gross Pay:</div>
            </td>
            <td>
                <div class="attribute">
                    {{ number_format($data['basic_salary'], 2) }}
                </div>
            </td>
        </tr>
        <tr>
            <td>
                <div>
                    <strong>Deductions Before
                        Tax:</strong>
                </div>
            </td>
            <td>
                <div class="attribute"> </div>
            </td>
        </tr>
        <tr>
            <td>
                <div>N.S.S.F:</div>
            </td>
            <td>
                <div class="attribute">
                    -{{ number_format($data['nssf'], 2) }}
                </div>
            </td>
        </tr>


        <tr>
            <td>
                <strong>Taxable Pay:</strong>
            </td>
            <td>
                <div class="attribute">
                    {{ number_format($data['basic_salary'] - $data['nssf'], 2) }}
                </div>
            </td>
        </tr>

        <tr>
            <td>
                <div>Income Tax:</div>
            </td>
            <td>
                <div class="attribute">
                    {{ number_format($data['income_tax'], 2) }}
                </div>
            </td>
        </tr>
        <tr>
            <td>
                <div>Tax Relief:</div>
            </td>
            <td>
                <div class="attribute">
                    {{ number_format($data['tax_relief'], 2) }}
                </div>
            </td>
        </tr>
        <tr>
            <td>
                <div><strong>P.A.Y.E:</strong></div>
            </td>
            <td>
                <div class="attribute">
                    -{{ number_format($data['net_paye'], 2) }}
                </div>
            </td>
        </tr>
    </table>
    <hr />
    <table style="width: 100%">
        <tr>
            <td>
                <div>Gross Pay after Tax:</div>
            </td>
            <td>
                <div class="attribute">
                    {{ number_format($data['pay_after_tax']) }}
                </div>
            </td>
        </tr>


        <tr>
            <td>
                <div>
                    <strong>Deductions After
                        Tax:</strong>
                </div>
            </td>
            <td>
                <div class="attribute">
                </div>
            </td>
        </tr>



        <tr>
            <td>
                <div>N.H.I.F.:</div>
            </td>
            <td>
                <div class="attribute">
                    -{{ number_format($data['nhif'], 2) }}
                </div>
            </td>
        </tr>
        <tr>
            <td>
                <div>Housing Levy</div>
            </td>
            <td>
                <div class="attribute">
                    -{{ number_format($data['housing_levy'], 2) }}
                </div>
            </td>
        </tr>

        @if ($data['total_loans'])
            <tr>
                <td>
                    <div>Loans:</div>
                </td>
                <td>
                    <div class="attribute">
                        {{ number_format($data['total_loans'], 2) }}
                    </div>
                </td>
            </tr>
        @endif
        @if ($data['total_advance'])
            <tr>
                <td>
                    <div>Advance:</div>
                </td>
                <td>
                    <div class="attribute">
                        {{ number_format($data['total_advance'], 2) }}
                    </div>
                </td>
            </tr>
        @endif
        @if ($data['total_deduction'])
            <tr>
                <td>
                    <div>Other Deductions:</div>
                </td>
                <td>
                    <div class="attribute">
                        {{ number_format($data['total_deduction'], 2) }}
                    </div>
                </td>
            </tr>
        @endif
       
    </table>
    <hr />
    <table style="width: 100%">
        <tr>
            <td>
                <div><strong>Net Pay:</strong></div>
            </td>
            <td>
                <div class="attribute">
                    {{ number_format($data['net_salary'], 2) }}
                </div>
            </td>
        </tr>

    </table>
    <hr />
    <table style="width: 100%">
        @if ($data['employee']['pay_method'] == 'bank_transfer')
            <tr>
                <td>
                    <div>
                        <strong>Personal Info:</strong>
                    </div>
                </td>
                <td>
                    <div class="attribute">
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <div>
                        <div>Payment Mode::</div>
                        <div>Bank Transfer</div>
                    </div>
                </td>
                <td>
                    <div class="attribute">
                        <div>Bank And Branch::</div>
                        <div>
                            {{ $data['employee']['bank_name'] }}
                            /
                            {{ $data['employee']['bank_branch'] }}
                        </div>
                    </div>
                </td>

            </tr>
        @endif
        <tr>
            <td>
                <div>
                    <div>Acc Name:: Account No</div>
                </div>
            </td>
            <td>
                <div class="attribute">
                    {{ $data['employee']['account_name'] }}
                    /
                    {{ $data['employee']['account_no'] }}
                </div>
            </td>
        </tr>
    </table>


    @if ($data['employee']['pay_method'] == 'mobile_money')
        <table style="width: 100%">
            <td>
                <div>
                    <strong>Personal Info:</strong>
                </div>
                <div></div>
            </td>
            <td>
                <div class="attribute">
                    <div>Payment Mode::</div>
                    <div>Mobile Money</div>
                </div>
            </td>
            <td>
                <div class="attribute">
                    <div>Phone Number::</div>
                    <div>
                        {{ $data['employee']['payment_phone'] }}
                    </div>
                </div>
            </td>
        </table>
    @endif
    <table>
        <tr>
            <td> salary from <b>{{ $data['payroll_from'] }}</b> to <b>{{ $data['payroll_to'] }}</b></td>
        </tr>

    </table>
</body>

</html>
